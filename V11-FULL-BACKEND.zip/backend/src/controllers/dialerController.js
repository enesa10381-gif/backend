// Dialer controller
