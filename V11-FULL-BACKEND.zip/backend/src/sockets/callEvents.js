// Socket call events
