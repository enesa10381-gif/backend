// Socket admin events
