// Customer model
