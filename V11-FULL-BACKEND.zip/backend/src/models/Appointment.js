// Appointment model
