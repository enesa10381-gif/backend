// AutoDialer engine
