// Soft pacing + night block
