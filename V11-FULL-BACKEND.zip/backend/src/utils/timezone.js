// Dual timezone tools
